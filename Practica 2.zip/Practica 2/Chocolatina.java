package ActividadesEjercicios;

import java.util.Objects;

public class Chocolatina {
    private String marca; // atributo privado "marca" de tipo String
    private int unidades; // atributo privado "unidades" de tipo int

    public Chocolatina(String marca, int unidades) { // constructor de la clase Chocolatina que inicializa los atributos "marca" y "unidades"
        this.marca = marca; // asigna el valor del parámetro "marca" al atributo "marca"
        this.unidades = unidades; // asigna el valor del parámetro "unidades" al atributo "unidades"
    }

    public String getMarca() { // método público "getMarca" que devuelve el valor del atributo "marca"
        return marca;
    }

    public void setMarca(String marca) { // método público "setMarca" que establece el valor del atributo "marca"
        this.marca = marca;
    }

    public int getUnidades() { // método público "getUnidades" que devuelve el valor del atributo "unidades"
        return unidades;
    }

    public void setUnidades(int unidades) { // método público "setUnidades" que establece el valor del atributo "unidades"
        this.unidades = unidades;
    }

    public boolean equals(Object o) { // método público "equals" que compara si dos objetos Chocolatina son iguales en base a sus atributos
        if (this == o) return true; // si los objetos son iguales en memoria, devuelve true
        if (o == null || getClass() != o.getClass()) return false; // si el objeto pasado como parámetro es null o no es de la clase Chocolatina, devuelve false
        Chocolatina that = (Chocolatina) o; // convierte el objeto pasado como parámetro en un objeto Chocolatina
        return unidades == that.unidades && Objects.equals(marca, that.marca); // devuelve true si los atributos "unidades" y "marca" son iguales en ambos objetos Chocolatina
    }

    public int hashCode() { // método público "hashCode" que devuelve un valor numérico que representa al objeto
        return Objects.hash(marca, unidades); // devuelve un valor hash basado en los valores de los atributos "marca" y "unidades"
    }
}