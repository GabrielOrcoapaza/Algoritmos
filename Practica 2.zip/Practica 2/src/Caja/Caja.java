package Caja;

import java.util.ArrayList;
import java.util.Iterator;

public class Caja<T> {

    // Campos de la clase
    private String color;
    private ArrayList<T> contenido;

    // Constructor de la clase, recibe un color y lo asigna al campo 'color'
    // Además, inicializa la lista 'contenido'
    public Caja(String color) {
        this.color = color;
        contenido = new ArrayList<>();
    }

    // Método para obtener el color de la caja
    public String getColor() {
        return color;
    }

    // Método para agregar un objeto a la lista 'contenido'
    public void add(T objeto) {
        contenido.add(objeto);
    }

    // Método para eliminar un objeto específico de la lista 'contenido'
    // Devuelve el objeto eliminado o null si no se encuentra
    public T remove(T objeto) {
        int index = contenido.indexOf(objeto);
        if (index >= 0) {
            return contenido.remove(index);
        } else {
            return null;
        }
    }

    // Método para verificar si un objeto está en la lista 'contenido'
    // Devuelve true si el objeto está en la lista, false si no
    public boolean contains(T objeto) {
        return contenido.contains(objeto);
    }

    // Método para obtener una representación en formato de cadena de la caja
    // Incluye su color y los objetos contenidos
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Caja de color ").append(color).append(": [");
        for (T objeto : contenido) {
            sb.append(objeto.toString()).append(", ");
        }
        if (contenido.size() > 0) {
            sb.delete(sb.length() - 2, sb.length());
        }
        sb.append("]");
        return sb.toString();
    }

    // Método que devuelve un iterador para la lista 'contenido'
    // En este caso, el método simplemente devuelve 'null'
    public Iterator<Object> iterator() {
        return null;
    }
}












