package DemoMetodoGenerico;
//explicacion del código

public class DemoMetodoGenerico {
    //Define un método genérico que recibe dos arrays de tipo T y devuelve true si su contenido es igual, o false en caso contrario
    static <T extends Comparable<T>> boolean igualArrays(T[] x, T[] y) {
        //Si las longitudes de los array son diferentes, entonces los array son diferentes
        if (x.length != y.length) {
            return false;
        }
        for (int i = 0; i < x.length; i++) {
            //Si alguno de los elementos no es igual, entonces los arrays son diferentes
            if (!x[i].equals(y[i])) {
                return false;
            }
        }
        //los arrays son iguales
        return true;
    }
    
    public static void main(String[] args) {
        //Crea arrays de tipo Integer para probar el método igualArrays
        Integer nums[] = {1, 2, 3, 4, 5};
        Integer nums2[] = {1, 2, 3, 4, 5};
        Integer nums3[] = {1, 2, 7, 4, 5};
        Integer nums4[] = {1, 2, 7, 4, 5, 6};
        
        //Prueba el método igualArrays con los distintos arrays creados anteriormente, imprimiendo un mensaje indicando si son iguales o diferentes
        if (igualArrays(nums, nums)) {
            System.out.println("nums es igual a nums");
        }
        if (igualArrays(nums, nums2)) {
            System.out.println("nums es igual a nums2");
        }
        if (igualArrays(nums, nums3)) {
            System.out.println("nums es igual a num3");
        }
        if (igualArrays(nums, nums4)) {
            System.out.println("nums es igual a nums4");
        }
        
        //Crea algunos arrays de tipo Double para probar el método igualArrays
        Double dvals[] = {1.1, 2.2, 3.3, 4.4, 5.5}; //A
        Double dvals2[] = {1.1, 2.2, 3.3, 4.4, 5.5}; //A
        
        //Prueba el método igualArrays con los arrays de tipo Double
        if (igualArrays(dvals, dvals2)) { //B
        	//imprime un mensaje indicando si son iguales o diferentes
            System.out.println("nums es igual a dvals"); //C
        }
    }
}