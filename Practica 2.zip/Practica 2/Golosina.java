package ActividadesEjercicios;

import java.util.Objects;

public class Golosina {
	private String nombre;//Declara la variable de instancia nombre como un objeto String privado
	private double peso; //eclara la variable de instancia peso como un valor double privado
	//Constructor que toma dos parámetros, "nombre" y "peso", y los utiliza para inicializar las variables de instancia correspondientes
	public Golosina(String nombre, double peso) {
		this.nombre = nombre;
		this.peso = peso;
	}
	//Devuelve el valor actual de la variable de instancia "nombre"
	public String getNombre() {
		return this.nombre;
	}
	//Establece el valor de la variable de instancia "nombre" a un nuevo valor pasado como parámetro
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	//Devuelve el valor actual de la variable de instancia "peso"
	public double getPeso() {
		return this.peso;
	}
	//Establece el valor de la variable de instancia "peso" a un nuevo valor pasado como parámetro
	public void setPeso(double peso) {
		this.peso = peso;
	}
	 public boolean equals(Object o) {
	        if (this == o) return true;
	        if (o == null || getClass() != o.getClass()) return false;
	        Golosina golosina = (Golosina) o;
	        return peso == golosina.peso && Objects.equals(nombre, golosina.nombre);
	    }
	    public int hashCode() {
	        return Objects.hash(nombre, peso);
	    }
}

