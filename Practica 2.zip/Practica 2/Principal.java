package ActividadesEjercicios;

public class Principal {
	public static void main(String[] args) {
		// Crea una instancia de la clase Bolsa con tipo de elemento Chocolatina, y tamaño máximo 5
		Bolsa<Chocolatina> bolsaCho = new Bolsa<Chocolatina>(5);
		// Crea una instancia de la clase Bolsa con tipo de elemento Golosina, y tamaño máximo 5.
		Bolsa<Golosina> bolsaGol = new Bolsa<Golosina>(5);

		// Crea instancias de la clase Chocolatina con distintas marcas.
		Chocolatina c = new Chocolatina("milka", 20);
		Chocolatina c1 = new Chocolatina("milka", 20);
		Chocolatina c2 = new Chocolatina("ferrero", 10);

		// Agrega las chocolatinas a la bolsa de chocolates
		bolsaCho.add(c);
		bolsaCho.add(c1);
		bolsaCho.add(c2);

		// Recorre la bolsa de chocolates e imprime la marca de cada chocolatina
		System.out.println("La bolsa de Chocolatinas contiene: ");
		for (Chocolatina chocolatina : bolsaCho) {
			System.out.println(chocolatina.getMarca());
		}

		// Llena la bolsa de golosinas
		llenarBolsaGolosinas(bolsaGol);
		
		// Imprime el contenido de la bolsa de golosinas
		System.out.println("La bolsa de Golosinas contiene: ");
		for (Golosina golosina : bolsaGol) {
			System.out.println(golosina.getNombre());
		}
	}

	// Método genérico para llenar una bolsa de golosinas
	public static <T extends Golosina> void llenarBolsaGolosinas(Bolsa<T> bolsa) {
		// Crea instancias de la clase Golosina con distintos nombres y cantidades
		T g1 = (T) new Golosina("chicles", 50);
		T g2 = (T) new Golosina("caramelos", 30);
		T g3 = (T) new Golosina("mentas", 20);
		T g4 = (T) new Golosina("paletas", 10);

		// Agrega las golosinas a la bolsa
		bolsa.add(g1);
		bolsa.add(g2);
		bolsa.add(g3);
		bolsa.add(g4);
	}
}







