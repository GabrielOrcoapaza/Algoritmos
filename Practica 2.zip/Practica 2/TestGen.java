package ActividadesEjercicios;

public class TestGen {

    // Método genérico para buscar un elemento en un arreglo de tipo T
    public static <T> boolean exist(T[] array, T elem) {
        for (T e : array) { // Recorre el arreglo usando un bucle for-each
            if (e.equals(elem)) { // Compara el elemento actual con el elemento buscado
                return true; // Devuelve true si el elemento es encontrado
            }
        }
        return false; // Devuelve false si el elemento no es encontrado
    }

    // Método principal que inicia la ejecución del programa
    public static void main(String[] args) {
        
        // Se crean dos arreglos: uno de cadenas de texto y otro de enteros
        String[] v = {"Perez", "Sanchez", "Rodriguez"};
        Integer[] w = {12, 34, 56};

        // Se llama al método "exist" con diferentes argumentos para comprobar si un elemento está presente en el arreglo
        System.out.println(exist(v, "Sanchez")); // Devuelve true
        System.out.println(exist(w, 34)); // Devuelve true
        System.out.println(exist(w, "Salas")); // Produce un error de compilación porque no se puede comparar un Integer con un String
    }
}




