package ActividadesEjercicios;
import java.util.ArrayList; //implementa una lista dinámica que puede cambiar de tamaño durante la ejecución de un programa. 
import java.util.Iterator; //iterfaz utilizada para recorrer una colección de elementos

public class Bolsa < T > implements Iterable < T > { //declara la clase genérica Bolsa con parámetro "T" e implementa la interfaz Iterable con el tipo de parámetro "T"
	private ArrayList < T > lista = new ArrayList < T > (); //"lista" es una instancia de ArrayList vacío con el tipo de parámetro "T"
	private int tope; //representa el tamaño máximo de la bolsa
	//Constructor: inicializa el tamaño máximo de la bolsa con el valor pasado como argumento
	public Bolsa(int tope) {
		super();
		this.tope = tope;
	}
	//define el método "add" de la clase Bolsa, que agrega un objeto "T" a la bolsa si el tamaño actual de la bolsa es menor que el tamaño máximo "tope"
	public void add(T objeto) {
		if (lista.size() < tope) { 
		//if (lista.size() < tope && objeto instanceof Caja) {
			lista.add(objeto);
		} else {
			throw new RuntimeException("no caben mas");//Si la bolsa está llena, el método lanza una excepción "RuntimeException".
		}
	}
	
	//define el método "iterator" de la clase Bolsa, que devuelve un objeto Iterator que permite recorrer los elementos de la bolsa en un bucle "for-each"
	public Iterator < T > iterator() {
		return lista.iterator();
	}
}

